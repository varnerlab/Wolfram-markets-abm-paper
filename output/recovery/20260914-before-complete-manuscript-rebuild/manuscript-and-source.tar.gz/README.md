# Wolfram cellular-automaton market

**Model repair, 14 September 2026:** the original standing-quote execution
rule permits profitable round trips. Financial conclusions in the existing
manuscript require revalidation. New research uses the reserve-clearing model
and separate campaigns described in [code/repaired/README.md](code/repaired/README.md).
Run `bash code/run_all.sh repaired-tests` to check the repair, or
`bash code/run_all.sh repaired` to reproduce its model comparisons. The
commands below reproduce the archived model and manuscript.

The completed repair and its first 2,480 comparison runs are summarized in
[What survives the execution repair](output/repaired/ASSESSMENT.md).
The following 1,040 runs tested
[whether local influence raises follower cash gains](output/repaired/transmission-v1-pilot/ASSESSMENT.md).
The [fresh-market confirmation](output/repaired/transmission-confirmation-v1-full/ASSESSMENT.md)
completed 5,200 runs across 50 new starting markets and passed both
predeclared criteria for the primary deep-reserve setting.

This repository contains the manuscript and Julia implementation for a
three-state spatial market with paired rule quenches, agent balance sheets,
endogenous price feedback, and an explicit finite-or-unlimited dealer.

From the repository root:

```bash
bash code/run_all.sh tests
bash code/run_all.sh figures
bash code/run_all.sh all
```

`tests` is the default verification path. `figures` rebuilds the revised paper
figures from committed production CSVs. `all` reruns the production campaigns
before rebuilding figures. See [`code/data/README.md`](code/data/README.md) for
the campaign inventory and data provenance.

The peer-review follow-up is documented in [peer-review-response.md](peer-review-response.md).
Run `bash code/run_all.sh revision` to reproduce its added controls; see
[code/revision/README.md](code/revision/README.md) for the complete protocol.
